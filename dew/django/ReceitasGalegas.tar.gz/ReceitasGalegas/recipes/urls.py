from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('ReceitasGalegas.recipes.views',
    (r'^$', 'index'),
    (r'^(?P<recipe_id>\d+)/$', 'detail'),
    (r'^add$', 'create'),
    (r'^(?P<recipe_id>\d+)/edit$', 'edit'),
    (r'^(?P<recipe_id>\d+)/delete$', 'delete'),

    # Uncomment the next line to enable the admin:
    (r'^admin/', include(admin.site.urls)),
)
