# Create your views here.
from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect
from django.template.context import RequestContext
from django.core.urlresolvers import reverse

from ReceitasGalegas.recipes.models import Recipe
from recipes.forms import CreateRecipeForm

def index(request):
    recipes_list = Recipe.objects.all().order_by('-submission_date')

    return render_to_response('recipes/index.html',
                              {'recipes_list': recipes_list})

def detail(request, recipe_id):
    r = get_object_or_404(Recipe, pk=recipe_id)
    return render_to_response('recipes/detail.html', {'recipe': r})

def edit(request, recipe_id):
    r = get_object_or_404(Recipe, pk=recipe_id)
    if request.method == 'POST': # If the form has been submitted...
        form = CreateRecipeForm(request.POST) # A form bound to the POST data
        if form.is_valid(): # All validation rules pass
            r.title = form.cleaned_data['title']
            r.time = form.cleaned_data['time']
            r.ingredients = form.cleaned_data['ingredients']
            r.instructions = form.cleaned_data['instructions']
            r.save()
            return HttpResponseRedirect(reverse('ReceitasGalegas.recipes.views.detail', kwargs={'recipe_id':r.id})) # Redirect after POST
    else:

        form = CreateRecipeForm(initial={'title':r.title,
                                         'ingredients':r.ingredients,
                                         'time':r.time,
                                         'instructions':r.instructions}) # An unbound form

    return render_to_response('recipes/edit_recipe.html', {
        'form' : form, 'recipe_id' : recipe_id
    }, context_instance=RequestContext(request))

def delete(request, recipe_id):
    r = get_object_or_404(Recipe, pk=recipe_id)
    r.delete()
    return HttpResponseRedirect(reverse('ReceitasGalegas.recipes.views.index'))

def create(request):
    if request.method == 'POST': # If the form has been submitted...
        form = CreateRecipeForm(request.POST) # A form bound to the POST data
        if form.is_valid(): # All validation rules pass
            new_recipe = Recipe()
            new_recipe.title = form.cleaned_data['title']
            new_recipe.time = form.cleaned_data['time']
            new_recipe.ingredients = form.cleaned_data['ingredients']
            new_recipe.instructions = form.cleaned_data['instructions']
            new_recipe.save()
            return HttpResponseRedirect(reverse('ReceitasGalegas.recipes.views.index')) # Redirect after POST
    else:
        form = CreateRecipeForm() # An unbound form

    return render_to_response('recipes/create_recipe.html', {
        'form': form,
    }, context_instance=RequestContext(request))
