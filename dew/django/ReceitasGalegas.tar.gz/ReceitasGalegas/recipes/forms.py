# -*- coding: utf-8 -*-
from django import forms

class CreateRecipeForm(forms.Form):
    title = forms.CharField(max_length=200)
    ingredients = forms.CharField(widget=forms.Textarea())
    time = forms.CharField(max_length=200)
    instructions = forms.CharField(widget=forms.Textarea())
