# -*- coding: utf-8 -*-

from ReceitasGalegas.recipes.models import Recipe
from django.contrib import admin

admin.site.register(Recipe)
