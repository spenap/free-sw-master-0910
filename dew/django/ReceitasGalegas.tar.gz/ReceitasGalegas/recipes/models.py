from django.db import models

# Create your models here.
class Recipe(models.Model):
    title = models.CharField(max_length=200)
    ingredients = models.TextField()
    time = models.CharField(max_length=200)
    instructions = models.TextField()
    submission_date = models.DateTimeField(auto_now=True)

    def __unicode__(self):
        message = ('%(title)s - %(time)s' % {'title':self.title,
                                            'time':self.time})
        return message
