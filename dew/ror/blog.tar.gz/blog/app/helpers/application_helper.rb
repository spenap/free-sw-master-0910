module ApplicationHelper

  def errors_for(model)
    return "" if model.errors.blank?
    
    content_tag(:div,
      content_tag(:p, 'There are errors') +
      content_tag(:ul, model.errors.full_messages.map {|m| content_tag(:li, m)}.join.html_safe),
      :class => 'form_errors')
  end

end
