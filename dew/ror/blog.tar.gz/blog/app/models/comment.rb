class Comment < ActiveRecord::Base
  belongs_to :post, :dependent => :destroy

  validates :author, :content, :presence => true
end
