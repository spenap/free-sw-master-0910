class Post < ActiveRecord::Base
  belongs_to :author, :dependent => :destroy
  has_many :comments
  scope :published, where(:published => true)
  scope :draft, where(:published => false)

  # :with => regexp
  validates :title, :content, :presence => true

  # Pagination
  cattr_reader :per_page
  @@per_page = 2
end
