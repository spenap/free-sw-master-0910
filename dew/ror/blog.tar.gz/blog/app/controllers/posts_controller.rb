class PostsController < ApplicationController

  def index
    @posts = Post.published.order('created_at desc').paginate(:page => params[:page], :per_page => Post.per_page)
  end

  def show
    @post = Post.find(params[:id])
  end

  def new
    @post = Post.new
  end

  def create
    @post = Post.new(params[:post])
    if @post.save
      #flash[:notice] = 'Post created'
      #flash.notice = 'Post created'
      redirect_to @post, :notice => 'Post created'
    else
      render 'new'
    end
  end

  def drafts
    @posts = Post.draft.order('created_at desc')
  end

  def edit
    @post = Post.find(params[:id])
  end

  def update
    @post = Post.find(params[:id])
    if @post.update_attributes(params[:post])
      redirect_to @post, :notice => 'Post updated'
    else
      render 'edit'
    end
  end

  def destroy
    post = Post.find(params[:id])
    post.destroy
    redirect_to posts_url, :notice => "Post #{post.title} destroyed"
  end

  def archive
    if params[:day]
      start = Time.utc(params[:year], params[:month], params[:day])
      finish = start + 1.day
    elsif params[:month]
      start = Time.utc(params[:year], params[:month])
      finish = start + 1.month
    else
      start = Time.utc(params[:year])
      finish = start + 1.year
    end
    @posts = Post.where('created_at BETWEEN ? AND ?', start.to_s(:db), finish.to_s(:db)).order('created_at desc')
    @start_date = start
    @finish_date = finish
  end

end
